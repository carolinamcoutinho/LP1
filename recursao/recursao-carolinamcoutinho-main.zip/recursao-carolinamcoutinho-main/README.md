# Aula4

# Exercícios de Recursão

<img alt="points bar" align="right" height="36" src="../../blob/status/.github/activity-icons/points-bar.svg" />

Modifique os arquivos na pasta src. Não modifique o nome dos executáveis no Makefile. Não modifique a pasta .github.

## Exercício 1

1. Implemente um código que recebe um número positivo N e retorna o fatorial desse número.

2. Envie suas modificações para o repositório GitHub. 

3. Aguarde um instante para os testes de correção. Atualize a página para ver o resultado.

## Exercício 2

1. Implemente um código que recebe um número positivo N e retorna o N-ésimo número da série de Fibonacci. 

## Exercício 3

1. Implemente um código que recebe dois números positivos X e Y e retorna o máximo divisor comum entre eles.
